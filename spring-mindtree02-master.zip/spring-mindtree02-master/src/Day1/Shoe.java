package Day1;

public interface Shoe {
	public void makeShoeComfortable();
	public void makeShoeLookGood();
	public void setPrice(int price);
	public int getPrice();
}
