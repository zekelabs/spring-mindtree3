package Day1;

import org.springframework.beans.factory.annotation.Autowired;

public class ShoeShowRoom {

	@Autowired
	Shoe s1;
}
