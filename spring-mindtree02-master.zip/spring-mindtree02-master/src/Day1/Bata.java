package Day1;

public class Bata implements Shoe{

	public Bata(){
		System.out.println("Creating Bata Shoes");
	}
	@Override
	public void makeShoeComfortable() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makeShoeLookGood() {
		System.out.println("Making Shoe Look Good since 1827");
		
	}

	@Override
	public void setPrice(int price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	

	
}
